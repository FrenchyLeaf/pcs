#include <iostream>

using namespace std;

int main()
{
    cout << "Hello, I'm a future program !" << endl;
    return 0;
}
